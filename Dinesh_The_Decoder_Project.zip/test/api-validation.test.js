import test from "node:test";
import assert from "node:assert/strict";

const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";

test("health page is served", async () => {
  const response = await fetch(baseUrl);
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") || "", /text\/html/);
});

test("missing task/code is rejected", async () => {
  const response = await fetch(`${baseUrl}/api/help`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ task: "explain", code: "" })
  });
  assert.equal(response.status, 400);
  const body = await response.json();
  assert.equal(typeof body.error, "string");
});
