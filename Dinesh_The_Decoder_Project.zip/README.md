# Decoder AI — by Dinesh The Decoder

An open-source starter project for a beginner-friendly AI coding helper. The first version can explain code, suggest debugging steps, and propose unit tests using the Anthropic API.

> **Status:** Early starter project. It has not yet been tested or deployed by the project owner. API access requires an Anthropic API key and may incur charges.

## Features

- Simple browser interface
- Explain code in beginner-friendly language
- Suggest likely bugs and fixes
- Generate example unit tests
- Keeps the API key on the server, not in browser JavaScript

## Requirements

- Node.js 20 or newer
- An Anthropic API key for AI responses
- Internet connection for API requests

## Run it locally

1. Install Node.js from https://nodejs.org/
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:

   ```bash
   npm install
   ```

5. Copy `.env.example` to a new file named `.env`.
6. Open `.env` and replace `your_api_key_here` with your own Anthropic API key.
7. Start the app:

   ```bash
   npm start
   ```

8. Open http://localhost:3000 in your browser.

**Important:** Do not upload `.env` to GitHub. The `.gitignore` file is configured to exclude it. API usage may cost money; check your Anthropic Console limits before testing.

## Automated smoke tests

Start the server in one terminal with `npm start`, then in a second terminal run `npm test`. These checks verify the page is served and invalid API input is rejected; they do not call the paid AI API.

## Deploy on Render

This repository includes `render.yaml` as a deployment blueprint. After pushing the project to GitHub, create a new Blueprint on [Render](https://render.com/) and select the repository. Add your `ANTHROPIC_API_KEY` as a secret environment variable in Render. Never commit the key to GitHub. Render plan availability and pricing can change, so confirm the current terms before deploying. A live deployment requires you to authorize the hosting account and provide your own API key.

## How to use

1. Choose **Explain code**, **Debug code**, or **Suggest tests**.
2. Paste a small code sample that you have permission to share.
3. Select **Help me** and read the response.

Do not paste passwords, API keys, private customer data, or confidential source code.

## Project structure

```text
dinesh-the-decoder/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── server.js
└── README.md
```

## Roadmap

- [x] Add basic automated smoke tests (page and input validation; no live AI API call)
- [ ] Improve error messages and input validation
- [ ] Add language selection and sample snippets
- [ ] Add accessibility checks
- [ ] Publish a live demo after testing and connecting a hosting account
- [ ] Add contribution guidelines and an open-source license

## Project description

Decoder AI is an early-stage open-source project exploring how AI can make coding easier to understand. It aims to help developers explain code, investigate likely errors, and draft unit tests through a simple interface.

## Project documents

- `START_HERE.md` — beginner setup and publishing checklist
- `CONTRIBUTING.md` — contribution guidelines
- `SECURITY.md` — security notes
- `LICENSE` — MIT License

## Contributing

Ideas, bug reports, and pull requests are welcome once the repository is published. Please avoid including secrets or private data in issues and example code. See `CONTRIBUTING.md` for details.
