# Contributing to Decoder AI

Thanks for your interest in improving Decoder AI!

## Before contributing
- Open an issue to describe a larger change before starting work.
- Never include API keys, passwords, private customer information, or confidential code.
- Keep changes small and explain how you tested them.

## Local setup
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and add an Anthropic API key if you want live AI responses.
4. Run `npm start` and visit `http://localhost:3000`.

## Pull requests
- Explain the reason for the change.
- Include steps to reproduce or test it.
- Do not claim a feature works unless you tested it.
