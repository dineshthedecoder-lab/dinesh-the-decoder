const form = document.querySelector("#helper-form");
const task = document.querySelector("#task");
const code = document.querySelector("#code");
const submitButton = document.querySelector("#submit-button");
const result = document.querySelector("#result");
const answer = document.querySelector("#answer");

document.querySelector("#year").textContent = new Date().getFullYear();

document.querySelector("#example-button").addEventListener("click", () => {
  code.value = `function addNumbers(a, b) {
  return a - b;
}

console.log(addNumbers(2, 3));`;
  task.value = "debug";
  code.focus();
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const snippet = code.value.trim();
  if (!snippet) {
    code.focus();
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Thinking...";
  result.hidden = false;
  answer.textContent = "Waiting for the AI response...";

  try {
    const response = await fetch("/api/help", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task: task.value, code: snippet })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    answer.textContent = data.answer || "No text response was returned.";
  } catch (error) {
    answer.textContent = error.message || "Could not connect to the server.";
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Help me <span>→</span>';
  }
});
