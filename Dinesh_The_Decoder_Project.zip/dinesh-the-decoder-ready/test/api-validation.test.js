import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";

const port = 3100 + Math.floor(Math.random() * 1000);
const baseUrl = `http://127.0.0.1:${port}`;
let server;

async function waitForServer(url, child, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Server exited early with code ${child.exitCode}`);
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("Server did not start in time");
}

test("API validation", async (t) => {
  server = spawn(process.execPath, ["server.js"], {
    env: { ...process.env, PORT: String(port) },
    stdio: "ignore"
  });

  t.after(() => {
    if (server && server.exitCode === null) server.kill("SIGTERM");
  });

  await waitForServer(baseUrl, server);

  await t.test("health page is served", async () => {
    const response = await fetch(baseUrl);
    assert.equal(response.status, 200);
    assert.match(response.headers.get("content-type") || "", /text\/html/);
  });

  await t.test("missing task/code is rejected", async () => {
    const response = await fetch(`${baseUrl}/api/help`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ task: "explain", code: "" })
    });
    assert.equal(response.status, 400);
    const body = await response.json();
    assert.equal(typeof body.error, "string");
  });
});
