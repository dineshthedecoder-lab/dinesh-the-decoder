# Security Policy

## Reporting a vulnerability
Please do not publish API keys, private data, or exploitable details in public issues. For now, contact the project maintainer privately before sharing sensitive security details.

## Safe use
- Keep `.env` private and never commit API keys.
- Do not paste confidential source code or personal data into the tool.
- Before public deployment, add rate limiting, monitoring, and appropriate abuse protection.
- AI responses can be incorrect; review suggested code before using it.
